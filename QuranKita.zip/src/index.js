import "regenerator-runtime";
import "./styles/style.css";
import "./scripts/components/AppBar";
import './scripts/components/SurahItem';
import './scripts/components/AudioItem';

import main from "./scripts/main";

main();
